package com.marwadi.sharedpreferencesmkv;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button b_login, b_reg;
    EditText e_user, e_pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b_login = findViewById(R.id.b_login);
        b_reg = findViewById(R.id.b_register);

        e_user = findViewById(R.id.e_user);
        e_pass = findViewById(R.id.e_pass);

        // Register Button
        b_reg.setOnClickListener(v -> {

            String username = e_user.getText().toString();
            String password = e_pass.getText().toString();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show();
            } else {

                SharedPreferences sp = getSharedPreferences("Data", MODE_PRIVATE);
                SharedPreferences.Editor editor = sp.edit();

                editor.putString("user", username);
                editor.putString("pass", password);
                editor.apply();

                Toast.makeText(this, "User created successfully", Toast.LENGTH_SHORT).show();

                e_user.setText("");
                e_pass.setText("");
            }
        });

        // Login Button
        b_login.setOnClickListener(v -> {

            String enteredUser = e_user.getText().toString();
            String enteredPass = e_pass.getText().toString();

            SharedPreferences sp = getSharedPreferences("Data", MODE_PRIVATE);

            if (sp.contains("user")) {

                String savedUser = sp.getString("user", "");
                String savedPass = sp.getString("pass", "");

                if (savedUser.equals(enteredUser) && savedPass.equals(enteredPass)) {

                    Toast.makeText(this, "Welcome", Toast.LENGTH_SHORT).show();

                } else {

                    Toast.makeText(this, "Sorry, user not found", Toast.LENGTH_SHORT).show();
                }

            } else {

                Toast.makeText(this, "No record found", Toast.LENGTH_SHORT).show();
            }
        });
    }
}