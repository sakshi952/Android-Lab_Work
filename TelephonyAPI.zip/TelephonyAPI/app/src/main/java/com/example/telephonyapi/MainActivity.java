package com.example.telephonyapi;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    TextView txt;
    EditText edt;
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        txt = findViewById(R.id.txt);
        edt = findViewById(R.id.editText);
        btn = findViewById(R.id.button)

        TelephonyManager telephonyManager = getSystemService(TELEPHONY_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {

            return;
        }
        String deviceSoftwareversion  = telephonyManager.getDeviceSoftwareVersion();
        String networkOperator = telephonyManager.getNetworkOperator();
        String carrier = telephonyManager.getNetworkOperatorName();

        String net = null;
        int netType = telephonyManager.getNetworkType();
        switch (netType) {
            case TelephonyManager.NETWORK_TYPE_GSM:
                net = "2g";
                break;
            case TelephonyManager.NETWORK_TYPE_HSDPA:
            case TelephonyManager.NETWORK_TYPE_HSPA:
            case TelephonyManager.NETWORK_TYPE_HSPAP:
            case TelephonyManager.NETWORK_TYPE_HSUPA:
                net = "3g";
            case TelephonyManager.NETWORK_TYPE_LTE:
                net = "4g";
                break;
            case TelephonyManager.NETWORK_TYPE_NR:
                net = "5g";
                break;
           }
           txt.setText(deviceSoftwareversion + ":" + networkOperator + ":" + carrier +":" + net);

           btn.setOnClickListener(v -> );
           Intent intent = new Intent(Intent.ACTION_CALL);
           intent.setData(Uri.parse("TEL"+91"+edt.getText().ToString()));
           startActivity(intent);



        });
    }
}